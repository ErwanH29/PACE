# Compilers
CC = /home/erwanh/miniforge3/envs/AMUSE_Env/bin/x86_64-conda-linux-gnu-cc
CXX = /home/erwanh/miniforge3/envs/AMUSE_Env/bin/x86_64-conda-linux-gnu-c++

MPICC = mpicc
MPICXX = mpicxx

CPU_COUNT = 8

# Tools
AR = /home/erwanh/miniforge3/envs/AMUSE_Env/bin/x86_64-conda-linux-gnu-ar
RANLIB = /home/erwanh/miniforge3/envs/AMUSE_Env/bin/x86_64-conda-linux-gnu-ranlib
DOWNLOAD = wget --progress=bar:force:noscroll --user-agent='' -O -


# General flags and libraries
CFLAGS = -march=nocona -mtune=haswell -ftree-vectorize -fPIC -fstack-protector-strong -fno-plt -O2 -ffunction-sections -pipe -isystem /home/erwanh/miniforge3/envs/AMUSE_Env/include 
LDFLAGS = -Wl,-O2 -Wl,--sort-common -Wl,--as-needed -Wl,-z,relro -Wl,-z,now -Wl,--disable-new-dtags -Wl,--gc-sections -Wl,--allow-shlib-undefined -Wl,-rpath,/home/erwanh/miniforge3/envs/AMUSE_Env/lib -Wl,-rpath-link,/home/erwanh/miniforge3/envs/AMUSE_Env/lib -L/home/erwanh/miniforge3/envs/AMUSE_Env/lib -L/home/erwanh/miniforge3/envs/AMUSE_Env/lib -Wl,-rpath,/home/erwanh/miniforge3/envs/AMUSE_Env/lib

LIBS = 


# External dependencies
GSL_FLAGS = -I/home/erwanh/miniforge3/envs/AMUSE_Env/include
GSL_LIBS = -L/home/erwanh/miniforge3/envs/AMUSE_Env/lib -lgsl -lgslcblas -lm -lcblas -lm
