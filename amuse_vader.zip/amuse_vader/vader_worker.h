#include "stdbool.h"

int cleanup_code();

int commit_parameters();

int evolve_model(double tlim);

int get_PostTimestep(bool * PostTimestep);

int get_PreTimestep(bool * PreTimestep);

int get_alpha(double * alpha);

int get_alpha_function(bool * alpha_func);

int get_area_of_index(int * i, double * area, int number_of_points);

int get_begin_time(double * begin_time);

int get_delta(double * delta);

int get_dtMin(double * dtMin);

int get_dtStart(double * dtStart);

int get_dtTol(double * dtTol);

int get_effective_potential_of_index(int * i, double * psiEff, int number_of_points);

int get_energy_source_out(int * i, double * eSrcOut, int number_of_points);

int get_eos_function(bool * eos_func);

int get_errTol(double * errTol);

int get_gamma(double * gamma);

int get_gravitational_potential_of_index(int * i, double * psi_grav, int number_of_points);

int get_grid_column_density(int * i, double * sigma, int number_of_points);

int get_grid_internal_energy(int * i, double * internal_energy, int number_of_points);

int get_grid_pressure(int * i, double * pressure, int number_of_points);

int get_grid_state(int * i, double * sigma, double * pressure, double * internal_energy, int number_of_points);

int get_grid_user_output(int * n, int * i, double * user_output, int number_of_points);

int get_index_of_position(double r, int * i);

int get_inner_boundary_energy_out(double * eSrcOut);

int get_inner_boundary_function(bool * ibc_func);

int get_inner_boundary_mass_out(double * mSrcOut);

int get_inner_enthalpy_boundary_enthalpy(double * ibc_enth_val);

int get_inner_enthalpy_boundary_enthalpy_gradient(double * ibc_enth_val);

int get_inner_enthalpy_boundary_type(int * ibc_enth);

int get_inner_pressure_boundary_mass_flux(double * ibc_pres_val);

int get_inner_pressure_boundary_torque(double * ibc_pres_val);

int get_inner_pressure_boundary_torque_flux(double * ibc_pres_val);

int get_inner_pressure_boundary_type(int * ibc_pres);

int get_internal_energy_source_function(bool * internal_energy_source_func);

int get_internal_energy_source_value(double * internal_energy_source_value);

int get_interpOrder(int * interpOrder);

int get_mass_source_function(bool * mass_source_func);

int get_mass_source_out(int * i, double * mSrcOut, int number_of_points);

int get_mass_source_value(double * mass_source_value);

int get_maxDtIncrease(double * maxDtIncrease);

int get_maxIter(int * maxIter);

int get_maxStep(int * maxStep);

int get_nUserOut(int * nUserOut);

int get_number_of_cells(int * i);

int get_number_of_user_parameters(int * n);

int get_outer_boundary_energy_out(double * eSrcOut);

int get_outer_boundary_function(bool * obc_func);

int get_outer_boundary_mass_out(double * mSrcOut);

int get_outer_enthalpy_boundary_enthalpy(double * obc_enth_val);

int get_outer_enthalpy_boundary_enthalpy_gradient(double * obc_enth_val);

int get_outer_enthalpy_boundary_type(int * obc_enth);

int get_outer_pressure_boundary_mass_flux(double * obc_pres_val);

int get_outer_pressure_boundary_torque(double * obc_pres_val);

int get_outer_pressure_boundary_torque_flux(double * obc_pres_val);

int get_outer_pressure_boundary_type(int * obc_pres);

int get_parameter(int i, double * param);

int get_position_of_index(int i, double * r);

int get_rotational_velocity_of_index(int * i, double * vphi, int number_of_points);

int get_tabulated_radius(int i, double * rTab);

int get_tabulated_size(int * nTab);

int get_tabulated_velocity(int i, double * vTab);

int get_time(double * time);

int get_useBE(bool * useBE);

int get_verbosity(int * verbosity);

int initialize_code();

int initialize_flat_grid(int n, bool linear, double rmin, double rmax, double vphi);

int initialize_keplerian_grid(int n, bool linear, double rmin, double rmax, double m);

int initialize_tabulated_grid(int n, int linear, double rmin, double rmax, int bspline_degree, int bspline_breakpoints);

int recommit_parameters();

int set_PostTimestep(bool PostTimestep);

int set_PreTimestep(bool PreTimestep);

int set_alpha(double alpha);

int set_alpha_function(bool alpha_func);

int set_begin_time(double begin_time);

int set_delta(double delta);

int set_dtMin(double dtMin);

int set_dtStart(double dtStart);

int set_dtTol(double dtTol);

int set_eos_function(bool eos_func);

int set_errTol(double errTol);

int set_gamma(double gamma);

int set_grid_column_density(int * i, double * sigma, int number_of_points);

int set_grid_internal_energy(int * i, double * internal_energy, int number_of_points);

int set_grid_pressure(int * i, double * pressure, int number_of_points);

int set_grid_state(int * i, double * sigma, double * pressure, double * internal_energy, int number_of_points);

int set_grid_user_output(int * n, int * i, double * user_output, int number_of_points);

int set_inner_boundary_function(bool ibc_func);

int set_inner_enthalpy_boundary_enthalpy(double ibc_enth_val);

int set_inner_enthalpy_boundary_enthalpy_gradient(double ibc_enth_val);

int set_inner_enthalpy_boundary_type(int ibc_enth);

int set_inner_pressure_boundary_mass_flux(double ibc_pres_val);

int set_inner_pressure_boundary_torque(double ibc_pres_val);

int set_inner_pressure_boundary_torque_flux(double ibc_pres_val);

int set_inner_pressure_boundary_type(int ibc_pres);

int set_internal_energy_source_function(bool internal_energy_source_func);

int set_internal_energy_source_value(double internal_energy_source_value);

int set_interpOrder(int interpOrder);

int set_mass_source_function(bool mass_source_func);

int set_mass_source_value(double mass_source_value);

int set_maxDtIncrease(double maxDtIncrease);

int set_maxIter(int maxIter);

int set_maxStep(int maxStep);

int set_nUserOut(int nUserOut);

int set_number_of_user_parameters(int n);

int set_outer_boundary_function(bool obc_func);

int set_outer_enthalpy_boundary_enthalpy(double obc_enth_val);

int set_outer_enthalpy_boundary_enthalpy_gradient(double obc_enth_val);

int set_outer_enthalpy_boundary_type(int obc_enth);

int set_outer_pressure_boundary_mass_flux(double obc_pres_val);

int set_outer_pressure_boundary_torque(double obc_pres_val);

int set_outer_pressure_boundary_torque_flux(double obc_pres_val);

int set_outer_pressure_boundary_type(int obc_pres);

int set_parameter(int i, double param);

int set_tabulated_radius(int i, double rTab);

int set_tabulated_size(int nTab);

int set_tabulated_velocity(int i, double vTab);

int set_useBE(bool useBE);

int set_verbosity(int verbosity);

int update_flat_grid(double vphi);

int update_keplerian_grid(double m);

int update_tabulated_grid(int bspline_degree, int bspline_breakpoints);

